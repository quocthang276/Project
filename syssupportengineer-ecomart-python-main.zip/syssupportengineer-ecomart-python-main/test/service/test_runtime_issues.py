# import sys
# from pathlib import Path

# PROJECT_ROOT = Path(__file__).resolve().parents[2]
# SRC_ROOT = PROJECT_ROOT / "src"
# if str(SRC_ROOT) not in sys.path:
#     sys.path.insert(0, str(SRC_ROOT))

# from controller.price_plan_comparator_controller import recommend
# from domain.electricity_reading import ElectricityReading
# from domain.price_plan import PricePlan
# from repository.electricity_reading_repository import ElectricityReadingRepository
# from repository.price_plan_repository import price_plan_repository
# from service.electricity_reading_service import ElectricityReadingService


# def test_electricity_reading_service_uses_requested_meter_id():
#     repository = ElectricityReadingRepository()
#     repository.store("smart-meter-1", [ElectricityReading({"time": 1, "reading": 0.5})])
#     repository.store("smart-meter-2", [ElectricityReading({"time": 2, "reading": 0.9})])

#     service = ElectricityReadingService(repository)
#     result = service.retrieve_readings_for("smart-meter-1")

#     assert len(result) == 1
#     assert result[0].reading == 0.5


# def test_recommend_returns_a_list_of_price_plan_recommendations():
#     repository = ElectricityReadingRepository()
#     repository.store(
#         "smart-meter-1",
#         [
#             ElectricityReading({"time": 100, "reading": 0.1}),
#             ElectricityReading({"time": 160, "reading": 0.2}),
#         ],
#     )

#     price_plan_repository.clear()
#     price_plan_repository.store([
#         PricePlan("price-plan-1", "Supplier A", 1),
#         PricePlan("price-plan-2", "Supplier B", 2),
#     ])

#     result = recommend("smart-meter-1", limit=2)

#     assert isinstance(result, list)
#     assert len(result) == 2
